document.addEventListener('DOMContentLoaded', () => {
  const cookieInfo = document.getElementById('cookieInfo');
  const status = document.getElementById('status');
  const newCookieField = document.getElementById('newCookie');
  const showBtn = document.getElementById('showBtn');
  const swapBtn = document.getElementById('swapBtn');
  const regionLockBypassBtn = document.getElementById('regionLockBypassBtn');

  const COOKIE_NAME = '.ROBLOSECURITY';
  const ROBLOX_URL = 'https://www.roblox.com';

  // SHOW My Cookie
  showBtn.onclick = () => {
    chrome.cookies.get({url: ROBLOX_URL, name: COOKIE_NAME}, cookie => {
      if (cookie) {
        cookieInfo.textContent = `My Cookie: ${cookie.value.substring(0,50)}...`;
        status.textContent = 'Showing my cookie!';
      } else {
        cookieInfo.textContent = 'No Roblox cookie found';
        status.textContent = 'Not logged in?';
      }
    });
  };

  // SWAP Cookie
  swapBtn.onclick = () => {
    const newValue = newCookieField.value.trim();
    if (!newValue) {
      status.textContent = 'Paste a cookie first!';
      return;
    }
    chrome.tabs.query({active: true, currentWindow: true}, tabs => {
      chrome.cookies.remove({url: ROBLOX_URL, name: COOKIE_NAME}, () => {
        chrome.cookies.set({
          url: ROBLOX_URL,
          name: COOKIE_NAME,
          value: newValue,
          domain: '.roblox.com',
          path: '/',
          secure: true,
          httpOnly: true,
          sameSite: 'no_restriction'
        }, () => {
          cookieInfo.textContent = `Swapped to: ${newValue.substring(0,50)}...`;
          status.textContent = 'Cookie swapped!';
          chrome.tabs.reload(tabs[0].id);
        });
      });
    });
  };

  // TOGGLE REGION LOCK BYPASS (Cosmetic Only)
  regionLockBypassBtn.onclick = () => {
    const isOn = regionLockBypassBtn.textContent.includes('ON');
    regionLockBypassBtn.textContent = isOn ? 'Region Lock Bypass (OFF)' : 'Region Lock Bypass (ON)';
    // No status update—just visual toggle
  };
});